"""
Pickle Opcode Scanner - Zero-dependency binary analysis of pickle files.

Parses pickle bytecode WITHOUT executing it, detecting dangerous opcodes that
invoke arbitrary functions (REDUCE, INST, OBJ, NEWOBJ, STACK_GLOBAL, BUILD).

This catches the #1 attack vector in ML supply chains: pickle deserialization
payloads embedded in .pkl, .pt, .pth, .bin model files.

References:
- Python pickletools module (stdlib) for opcode definitions
- JFrog PickleScan bypass research (2025-2026)
- MITRE ATLAS AML.T0010 (AI Supply Chain Compromise)
"""

import io
import logging
import struct
from pathlib import Path

from scanner.models import Finding
from scanner.rules.definitions import get_rule

# Pickle protocol opcodes relevant to security analysis
# See: https://docs.python.org/3/library/pickletools.html

logger = logging.getLogger(__name__)

PICKLE_MAGIC = b"\x80"  # Protocol header (protocol 2+)
# Maximum recursion depth when rescanning pickle payloads embedded inside
# another pickle's byte-string opcodes (staged / nested-pickle evasion).
_MAX_NESTED_DEPTH = 3
# A captured byte payload is only worth rescanning if it plausibly contains
# pickle opcodes; scanning arbitrary binary blobs would be wasteful.
_MIN_NESTED_PAYLOAD = 3

# Opcodes that can invoke arbitrary callables
OP_REDUCE = b"R"  # Apply callable to args tuple on stack
OP_INST = b"i"  # Instantiate class (protocol 0)
OP_OBJ = b"o"  # Build object (protocol 1)
OP_NEWOBJ = b"\x81"  # type.__new__(type, *args) (protocol 2)
OP_NEWOBJ_EX = b"\x92"  # type.__new__(type, *args, **kwargs) (protocol 4)
OP_STACK_GLOBAL = b"\x93"  # Push global from stack-based module.name (protocol 4)
OP_BUILD = b"b"  # obj.__setstate__(state) - can trigger code via __reduce__

# Additional dangerous opcodes for PickleScan bypasses
OP_REDUCE_EX = b"\x9a"  # __reduce_ex__ protocol 5 (protocol 5+)
OP_PERSID = b"P"  # PERSID - persistent ID (can invoke arbitrary code)

# Opcodes that load globals (modules/functions) by name
OP_GLOBAL = b"c"  # Push module.name global (protocol 0)
OP_SHORT_BINUNICODE = b"\x8c"  # Short binary unicode string
OP_BINUNICODE = b"X"  # Binary unicode string

# Copyreg opcodes
OP_COPYREG = b"\x9c"  # EXT4 - used for copyreg dispatch table

# Stop opcode
OP_STOP = b"."

# Dangerous modules/functions that should NEVER appear in model files
CRITICAL_CALLABLES = {
    # Direct code execution
    "os.system",
    "os.popen",
    "os.exec",
    "os.execl",
    "os.execle",
    "os.execlp",
    "os.execv",
    "os.execve",
    "os.execvp",
    "os.execvpe",
    "os.spawn",
    "os.spawnl",
    "os.spawnle",
    "os.spawnlp",
    "posix.system",
    "nt.system",
    "subprocess.call",
    "subprocess.check_call",
    "subprocess.check_output",
    "subprocess.Popen",
    "subprocess.run",
    "builtins.exec",
    "builtins.eval",
    "builtins.compile",
    "__builtin__.exec",
    "__builtin__.eval",
    "runpy.run_module",
    "runpy.run_path",
    # Import manipulation
    "builtins.__import__",
    "__builtin__.__import__",
    "importlib.import_module",
    "importlib.__import__",
    # Pickle-specific exploitation gadgets
    "pickle.loads",
    "pickle.load",
    "_pickle.loads",
    "_pickle.load",
    "copyreg._reconstructor",
    # Network access
    "urllib.request.urlopen",
    "urllib.request.urlretrieve",
    "http.client.HTTPConnection",
    "http.client.HTTPSConnection",
    "socket.socket",
    "socket.create_connection",
    "webbrowser.open",
    "requests.api.get",
    "requests.api.post",
    "requests.get",
    "requests.post",
    "requests.put",
    "requests.delete",
    "requests.request",
    # File system manipulation
    "shutil.rmtree",
    "shutil.move",
    "shutil.copy",
    "os.remove",
    "os.unlink",
    "os.rmdir",
    "os.makedirs",
    "os.rename",
    "os.chmod",
    "os.chown",
    "io.open",
    "builtins.open",
    "__builtin__.open",
    # ctypes / code loading
    "ctypes.cdll.LoadLibrary",
    "ctypes.CDLL",
    "ctypes.WinDLL",
    "ctypes.windll",
    # Expanded long-tail gadgets (added after benchmarking)
    "runpy._run_code",
    "timeit.timeit",
    "pydoc.locate",
    "lib2to3.pgen2.grammar.Grammar.loads",
    "pty.spawn",
    "operator.methodcaller",
    "functools.partial",
    "types.CodeType",
    "marshal.loads",
    "dill.loads",
    "joblib.load",
    "cloudpickle.loads",
    "torch.utils.collect_env.run",
    "torch.jit.unsupported_tensor_ops.execWrapper",
    "torch.utils.bottleneck.__main__.run_cprofile",
    # Profile/cProfile - can be used for code execution
    "profile.Profile.run",
    "cProfile.Profile.run",
    "profile.Profile.runcall",
    "cProfile.Profile.runcall",
    "profile.run",
    "cProfile.run",
    # trace module - can execute code
    "trace.Trace.run",
    "trace.Trace.runctx",
    # Idlelib (Python shell) - CVE-2024-34064 fix
    "idlelib.pyshell.ModifiedInterpreter.runcode",
}

# Suspicious but not immediately critical - require context
SUSPICIOUS_CALLABLES = {
    "collections.OrderedDict",  # Often benign in torch, but used in gadget chains
    "torch._utils._rebuild_tensor_v2",  # Legitimate but can be abused
    "numpy.core.multiarray._reconstruct",  # Legitimate numpy
    "numpy.ndarray",
    "_codecs.encode",  # Sometimes used for obfuscation
    "codecs.encode",
}

# Known PickleScan bypass techniques
BYPASS_PATTERNS = {
    # Using __reduce_ex__ instead of __reduce__
    "__reduce_ex__",
    # Overriding __setstate__ for BUILD opcode exploitation
    "__setstate__",
    # Using copyreg dispatch_table manipulation
    "copyreg.dispatch_table",
    "copyreg.pickle",
    # Abusing persistent_load
    "persistent_load",
    # Protocol 5 BYTEARRAY8 bypass
    "bytearray",
}

# Legitimate torch/numpy reconstruction functions (allowlist)
SAFE_ALLOWLIST = {
    "torch._utils._rebuild_tensor_v2",
    "torch._utils._rebuild_parameter",
    "torch._utils._rebuild_parameter_with_state",
    "torch.storage._load_from_bytes",
    "torch.FloatStorage",
    "torch.LongStorage",
    "torch.IntStorage",
    "torch.DoubleStorage",
    "torch.HalfStorage",
    "torch.BFloat16Storage",
    "torch.ShortStorage",
    "torch.CharStorage",
    "torch.ByteStorage",
    "torch.BoolStorage",
    "torch.ComplexFloatStorage",
    "torch.ComplexDoubleStorage",
    "torch.storage.TypedStorage",
    "torch.storage.UntypedStorage",
    "torch._C.HalfStorageBase",
    "torch._C.FloatStorageBase",
    "collections.OrderedDict",
    "numpy.core.multiarray._reconstruct",
    "numpy.ndarray",
    "numpy.dtype",
    "_codecs.encode",
}


def _make_finding(rule_id: str, file_path: str, evidence: str) -> Finding:
    rule = get_rule(rule_id)
    return Finding(
        rule_id=rule_id,
        severity=rule.severity,
        file_path=file_path,
        line_number=0,
        column=0,
        message=rule.description,
        evidence=evidence[:300],
        remediation=rule.remediation,
        cwe=rule.cwe,
    )


def _read_string_nl(data: bytes, pos: int) -> tuple[str, int]:
    """Read a newline-terminated string (protocol 0 GLOBAL/INST).

    Handles both \n and \r\n line endings for CRLF evasion fix.
    """
    end = data.index(b"\n", pos)
    # Strip trailing \r for CRLF parser-evasion hardening.
    s = data[pos:end].decode("ascii", errors="replace")
    if s.endswith("\r"):
        s = s[:-1]
    return s, end + 1


def _read_uint1(data: bytes, pos: int) -> tuple[int, int]:
    return data[pos], pos + 1


def _read_uint2(data: bytes, pos: int) -> tuple[int, int]:
    return struct.unpack_from("<H", data, pos)[0], pos + 2


def _read_uint4(data: bytes, pos: int) -> tuple[int, int]:
    return struct.unpack_from("<I", data, pos)[0], pos + 4


def _read_int4(data: bytes, pos: int) -> tuple[int, int]:
    return struct.unpack_from("<i", data, pos)[0], pos + 4


def _read_uint8(data: bytes, pos: int) -> tuple[int, int]:
    return struct.unpack_from("<Q", data, pos)[0], pos + 8


class PickleScanner:
    """
    Zero-execution pickle bytecode scanner.

    Parses opcodes sequentially, tracking the string stack to identify
    what functions are being called via REDUCE/INST/OBJ/NEWOBJ.
    """

    def __init__(self, file_path: str, data: bytes, _depth: int = 0):
        self.file_path = file_path
        self.data = data
        self.pos = 0
        self.findings: list[Finding] = []
        self.globals_found: list[str] = []
        self.reduces_found: int = 0
        self.string_stack: list[str] = []
        self.protocol = 0
        # Tracks opcodes we did not recognise - any unknown opcode
        # causes the scan result to be INDETERMINATE, not CLEAN.
        self.unknown_opcode_count: int = 0
        # Set to the exception text when opcode parsing aborts on a truncated /
        # corrupt stream. Used to drive INDETERMINATE (fail-loud) semantics.
        self.parse_error: str | None = None
        # Recursion depth for nested pickle-in-bytes payloads. An attacker can
        # hide a malicious pickle inside a BINBYTES payload of an outer pickle
        # (a two-stage / staged loader). We capture such payloads and rescan
        # them, bounded by _MAX_NESTED_DEPTH to avoid unbounded recursion.
        self._depth = _depth
        self.nested_payloads: list[bytes] = []

    def _checked_len(self, str_len: int, pos: int) -> int:
        """Validate that ``str_len`` bytes are actually present starting at ``pos``.

        Raises ValueError on truncation so scan() emits an INDETERMINATE (HFS-096)
        finding rather than silently reading a short (truncated) buffer and
        treating the stream as clean. A length-prefixed opcode that claims more
        bytes than the file contains is a hallmark of a truncated payload.
        """
        if str_len < 0:
            raise ValueError(f"negative length {str_len} at pos {pos}")
        if pos + str_len > len(self.data):
            raise ValueError(
                f"declared length {str_len} at pos {pos} exceeds data size {len(self.data)} "
                "(truncated pickle)"
            )
        return str_len

    def _maybe_capture_nested(self, payload: bytes) -> None:
        """Capture a byte-string payload if it plausibly holds a nested pickle.

        A staged-loader attack embeds a second pickle inside a BINBYTES payload
        of the outer pickle. The outer opcodes look benign; the malicious
        REDUCE/GLOBAL lives in the inner blob. We queue such payloads so scan()
        can rescan them (bounded by _MAX_NESTED_DEPTH).
        """
        if self._depth >= _MAX_NESTED_DEPTH:
            return
        if not payload or len(payload) < _MIN_NESTED_PAYLOAD:
            return
        # Only rescan blobs that look like a pickle: a protocol-2+ header, or
        # the presence of the opcodes that actually trigger code execution.
        if (
            payload[:1] == PICKLE_MAGIC
            or OP_GLOBAL in payload
            or OP_STACK_GLOBAL in payload
            or OP_REDUCE in payload
            or OP_INST in payload
        ):
            self.nested_payloads.append(payload)

    def scan(self) -> list[Finding]:
        """Main scan entry point."""
        if not self.data:
            return []

        # Detect pickle protocol version
        if self.data[0:1] == PICKLE_MAGIC and len(self.data) > 1:
            self.protocol = self.data[1]
            self.pos = 2
        else:
            self.protocol = 0
            self.pos = 0

        try:
            self._parse_opcodes()
        except (IndexError, struct.error, ValueError) as exc:
            # Corrupt / truncated pickle. This is INDETERMINATE, never CLEAN:
            # a malformed stream can execute code before deserialization finishes
            # (a known PickleScan bypass). We MUST fail loud even when zero
            # globals were parsed before the error - a truncated header alone is
            # unanalyzable, not safe.
            self.parse_error = str(exc) or exc.__class__.__name__
            if self.globals_found:
                self.findings.append(
                    _make_finding(
                        "HFS-052",
                        self.file_path,
                        f"Corrupted pickle with {len(self.globals_found)} globals parsed "
                        f"before error: {self.globals_found[:5]}",
                    )
                )
            self.findings.append(
                _make_finding(
                    "HFS-096",
                    self.file_path,
                    f"Pickle parse aborted ({self.parse_error}) - stream is truncated or "
                    "corrupt. Scan is INDETERMINATE; unanalyzed opcodes may remain. "
                    "Do not treat as clean.",
                )
            )

        # Post-scan analysis
        self._analyze_globals()
        self._check_reduce_count()
        # If unknown opcodes were encountered the stream could not be
        # fully analysed.  Emit an INDETERMINATE (HFS-096) finding so callers
        # cannot treat this scan as clean.
        if self.unknown_opcode_count > 0:
            self.findings.append(
                _make_finding(
                    "HFS-096",
                    self.file_path,
                    f"{self.unknown_opcode_count} unknown pickle opcode(s) encountered - "
                    "scan is INDETERMINATE. The stream may contain unanalysed code "
                    "execution paths. Do not treat as clean.",
                )
            )
        # Rescan any pickle payloads embedded inside byte-string opcodes.
        # This closes the staged/nested-pickle evasion where the outer pickle
        # is benign but a second pickle is hidden inside a BINBYTES payload.
        for payload in self.nested_payloads:
            nested = PickleScanner(self.file_path, payload, _depth=self._depth + 1)
            for finding in nested.scan():
                if "[nested pickle]" not in finding.message:
                    finding.message = f"[nested pickle] {finding.message}"
                self.findings.append(finding)

        return self.findings

    def _parse_opcodes(self):
        """Walk through pickle opcodes without executing."""
        data = self.data
        length = len(data)
        max_iterations = 1_000_000  # Safety limit

        for _ in range(max_iterations):
            if self.pos >= length:
                break

            op = data[self.pos : self.pos + 1]
            self.pos += 1

            if op == OP_STOP:
                break
            elif op == OP_GLOBAL:
                # "c" opcode: read module\nname\n
                module, self.pos = _read_string_nl(data, self.pos)
                name, self.pos = _read_string_nl(data, self.pos)
                full_name = f"{module}.{name}"
                self.globals_found.append(full_name)
                self.string_stack.append(full_name)
            elif op == OP_STACK_GLOBAL:
                # "\x93" opcode: pop name, pop module from stack
                if len(self.string_stack) >= 2:
                    name = self.string_stack.pop()
                    module = self.string_stack.pop()
                    full_name = f"{module}.{name}"
                    self.globals_found.append(full_name)
                    self.string_stack.append(full_name)
            elif op == OP_INST:
                # "i" opcode: read module\nname\n (protocol 0)
                module, self.pos = _read_string_nl(data, self.pos)
                name, self.pos = _read_string_nl(data, self.pos)
                full_name = f"{module}.{name}"
                self.globals_found.append(full_name)
                self.reduces_found += 1
            elif op in (OP_REDUCE, OP_OBJ, OP_NEWOBJ, OP_NEWOBJ_EX):
                self.reduces_found += 1
            elif op == OP_REDUCE_EX:
                # "\x9a" opcode: protocol 5 __reduce_ex__ - calls __reduce_ex__(protocol)
                # This is a PickleScan bypass - allows different reduction logic per protocol
                self.reduces_found += 1
                self.findings.append(
                    _make_finding(
                        "HFS-052",
                        self.file_path,
                        "Protocol 5 __reduce_ex__ opcode (OP_REDUCE_EX) detected - PickleScan bypass technique",
                    )
                )
            elif op == OP_PERSID:
                # "P" opcode: PERSID - persistent ID reference
                # Can invoke arbitrary persistent_load function
                self.reduces_found += 1
                self.findings.append(
                    _make_finding(
                        "HFS-052",
                        self.file_path,
                        "PERSID opcode detected - persistent_load bypass technique",
                    )
                )
            elif op == OP_BUILD:
                # BUILD can trigger __setstate__ which is exploitable
                self.reduces_found += 1
            elif op == OP_SHORT_BINUNICODE:
                # "\x8c" opcode: 1-byte length + string
                str_len, self.pos = _read_uint1(data, self.pos)
                self._checked_len(str_len, self.pos)
                s = data[self.pos : self.pos + str_len].decode("utf-8", errors="replace")
                self.pos += str_len
                self.string_stack.append(s)
            elif op == OP_BINUNICODE:
                # "X" opcode: 4-byte length + string
                str_len, self.pos = _read_uint4(data, self.pos)
                if str_len > 10_000_000:  # Safety limit
                    break
                self._checked_len(str_len, self.pos)
                s = data[self.pos : self.pos + str_len].decode("utf-8", errors="replace")
                self.pos += str_len
                self.string_stack.append(s)
            elif op == b"S":
                # String literal (protocol 0) - read until \n
                s, self.pos = _read_string_nl(data, self.pos)
                # Strip quotes
                s = s.strip("'\"")
                self.string_stack.append(s)
            elif op == b"V":
                # Unicode string (protocol 0)
                s, self.pos = _read_string_nl(data, self.pos)
                self.string_stack.append(s)
            elif op == b"T":
                # 4-byte length binary string
                str_len, self.pos = _read_uint4(data, self.pos)
                if str_len > 10_000_000:
                    break
                self.pos += str_len
            elif op == b"U":
                # 1-byte length binary string
                str_len, self.pos = _read_uint1(data, self.pos)
                self.pos += str_len
            elif op == b"B":
                # BINBYTES (4-byte length)
                str_len, self.pos = _read_uint4(data, self.pos)
                if str_len > 10_000_000:
                    break
                self._maybe_capture_nested(data[self.pos : self.pos + str_len])
                self.pos += str_len
            elif op == b"C":
                # SHORT_BINBYTES (1-byte length)
                str_len, self.pos = _read_uint1(data, self.pos)
                self._maybe_capture_nested(data[self.pos : self.pos + str_len])
                self.pos += str_len
            elif op == b"\x8e":
                # BINBYTES8 (8-byte length)
                str_len, self.pos = _read_uint8(data, self.pos)
                if str_len > 100_000_000:
                    break
                self._maybe_capture_nested(data[self.pos : self.pos + str_len])
                self.pos += str_len
            elif op == b"\x8d":
                # BINUNICODE8 (8-byte length)
                str_len, self.pos = _read_uint8(data, self.pos)
                if str_len > 100_000_000:
                    break
                self.pos += str_len
            elif op == b"G":
                # BINFLOAT (8 bytes)
                self.pos += 8
            elif op == b"J":
                # BININT (4 bytes)
                self.pos += 4
            elif op == b"K":
                # BININT1 (1 byte)
                self.pos += 1
            elif op == b"M":
                # BININT2 (2 bytes)
                self.pos += 2
            elif op == b"N":
                # NONE
                pass
            elif op == b"\x88":
                # NEWTRUE
                pass
            elif op == b"\x89":
                # NEWFALSE
                pass
            elif op == b"\x95":
                # FRAME (8-byte frame length, protocol 4)
                self.pos += 8
            elif op == b"\x94":
                # MEMOIZE (protocol 4)
                pass
            elif op == b"\x9c":
                # EXT4 - used for copyreg dispatch_table manipulation
                # This is a PickleScan bypass technique
                self.findings.append(
                    _make_finding(
                        "HFS-052",
                        self.file_path,
                        "EXT4/COPYREG opcode detected - copyreg dispatch_table manipulation bypass",
                    )
                )
            elif op == b"p":
                # PUT (protocol 0)
                _, self.pos = _read_string_nl(data, self.pos)
            elif op == b"q":
                # BINPUT (1-byte index)
                self.pos += 1
            elif op == b"r":
                # LONG_BINPUT (4-byte index)
                self.pos += 4
            elif op == b"g":
                # GET (protocol 0)
                _, self.pos = _read_string_nl(data, self.pos)
            elif op == b"h":
                # BINGET (1-byte index)
                self.pos += 1
            elif op == b"j":
                # LONG_BINGET (4-byte index)
                self.pos += 4
            elif op in (
                b"(",
                b")",
                b"l",
                b"d",
                b"t",
                b"}",
                b"]",
                b"\x85",
                b"\x86",
                b"\x87",
                b"\x90",
                b"\x91",
                b"0",
                b"1",
                b"2",
                b"a",
                b"e",
                b"s",
                b"u",
            ):
                # Stack manipulation and collection opcodes - no payload
                pass
            elif op == b"I":
                # INT (protocol 0) - read until \n
                _, self.pos = _read_string_nl(data, self.pos)
            elif op == b"L":
                # LONG (protocol 0) - read until \n
                _, self.pos = _read_string_nl(data, self.pos)
            elif op == b"F":
                # FLOAT (protocol 0) - read until \n
                _, self.pos = _read_string_nl(data, self.pos)
            elif op == b"\x8a":
                # LONG1 (1-byte length + data)
                n, self.pos = _read_uint1(data, self.pos)
                self.pos += n
            elif op == b"\x8b":
                # LONG4 (4-byte length + data)
                n, self.pos = _read_int4(data, self.pos)
                self.pos += max(0, n)
            elif op == PICKLE_MAGIC:
                # Nested protocol header
                self.pos += 1  # Skip version byte
            else:
                # Unknown opcode - we cannot reason about the pickle stream
                # beyond this point. Increment counter and stop parsing.
                # The caller will check unknown_opcode_count > 0 and
                # set the scan verdict to INDETERMINATE.
                self.unknown_opcode_count += 1
                break

    def _analyze_globals(self):
        """Classify discovered globals into critical/suspicious/safe."""
        for global_name in self.globals_found:
            normalized = global_name.strip()

            # Check critical callables
            if normalized in CRITICAL_CALLABLES:
                self.findings.append(
                    _make_finding(
                        "HFS-050", self.file_path, f"CRITICAL callable in pickle: {normalized}"
                    )
                )
            elif any(
                normalized.startswith(prefix)
                for prefix in (
                    "os.",
                    "subprocess.",
                    "builtins.",
                    "__builtin__.",
                    "nt.",
                    "posix.",
                    "ctypes.",
                    "shutil.",
                    "webbrowser.",
                    "runpy.",
                    "importlib.",
                )
            ):
                # Broader check - anything in these modules is suspicious
                if normalized not in SAFE_ALLOWLIST:
                    self.findings.append(
                        _make_finding(
                            "HFS-050",
                            self.file_path,
                            f"Dangerous module access in pickle: {normalized}",
                        )
                    )
            elif normalized in SUSPICIOUS_CALLABLES and normalized not in SAFE_ALLOWLIST:
                self.findings.append(
                    _make_finding(
                        "HFS-051", self.file_path, f"Suspicious callable in pickle: {normalized}"
                    )
                )
            # Check for bypass patterns in global names
            for pattern in BYPASS_PATTERNS:
                if pattern in normalized:
                    self.findings.append(
                        _make_finding(
                            "HFS-052",
                            self.file_path,
                            f"Known PickleScan bypass pattern: {pattern} in {normalized}",
                        )
                    )

    def _check_reduce_count(self):
        """Flag excessive REDUCE operations (indicator of gadget chains)."""
        # Legitimate torch models typically have many REDUCEs for tensor reconstruction
        # but extremely high counts with non-allowlisted globals are suspicious
        dangerous_globals = [g for g in self.globals_found if g not in SAFE_ALLOWLIST]
        if dangerous_globals and self.reduces_found > 0:
            # Already flagged by _analyze_globals, but add context
            pass
        elif self.reduces_found > 100 and not self.globals_found:
            # Many REDUCEs but no parseable globals - possibly obfuscated
            self.findings.append(
                _make_finding(
                    "HFS-051",
                    self.file_path,
                    f"{self.reduces_found} REDUCE ops with no recognizable globals - possible obfuscation",
                )
            )


def is_pickle_file(file_path: str | Path) -> bool:
    """Return True when the file starts with pickle bytes, regardless of extension.

    Also returns True for ZIP files that may contain pickle data (e.g., PyTorch .pt files).
    """
    pickle_magic = (
        b"\x80\x02",
        b"\x80\x03",
        b"\x80\x04",
        b"\x80\x05",
        b"(",
        b"c",
    )
    try:
        with open(file_path, "rb") as f:
            header = f.read(2)
    except (OSError, PermissionError):
        return False

    # Check for pickle magic bytes
    if any(header == magic or header[:1] == magic for magic in pickle_magic):
        return True

    # Check for ZIP files that may contain pickle data (e.g., PyTorch .pt files)
    # ZIP files start with PK (0x50 0x4B)
    if header == b"PK":
        return True

    return False


def scan_pickle_bytes(file_path: str, data: bytes) -> list[Finding]:
    """
    Scan raw bytes of a pickle file for malicious opcodes.

    Handles:
    - Standard pickle files
    - PyTorch files (ZIP containing data.pkl)
    - Concatenated pickles (multiple STOP opcodes)

    CVE-2025-10155: File extension mismatch detection
    CVE-2025-10156: ZIP CRC bypass detection
    """
    findings: list[Finding] = []

    # CVE-2025-10155: File extension mismatch - pickle content with non-pickle extension
    lower_path = file_path.lower()
    if not (
        lower_path.endswith((".pkl", ".pickle", ".pt", ".pth", ".bin", ".ckpt", ".joblib", ".zip"))
    ):
        # Check if it's actually a pickle file despite the extension
        if data[:1] == PICKLE_MAGIC or _looks_like_pickle(data):
            findings.append(
                _make_finding(
                    "HFS-052",
                    file_path,
                    f"CVE-2025-10155: File extension mismatch - {file_path} has pickle content but non-pickle extension",
                )
            )

    # Check if it's a ZIP file (PyTorch .pt format)
    if data[:2] == b"PK":
        findings.extend(_scan_pytorch_zip(file_path, data))
    elif data[:1] == PICKLE_MAGIC or _looks_like_pickle(data):
        # Direct pickle file
        scanner = PickleScanner(file_path, data)
        findings.extend(scanner.scan())
    else:
        # Try scanning anyway - some pickle files have no magic
        # Search for pickle opcodes in the first 1MB
        scan_window = data[:1_048_576]
        if OP_GLOBAL in scan_window or OP_STACK_GLOBAL in scan_window:
            scanner = PickleScanner(file_path, data)
            findings.extend(scanner.scan())

    return findings


def _looks_like_pickle(data: bytes) -> bool:
    """Heuristic: does this look like it could be a pickle stream?"""
    if not data:
        return False
    # Protocol 0 pickles start with various opcodes
    first_byte = data[0:1]
    return first_byte in (b"(", b"c", b"l", b"d", b"I", b"S", b"F", b"N", PICKLE_MAGIC)


def _scan_pytorch_zip(file_path: str, data: bytes) -> list[Finding]:
    """Extract and scan pickle entries from PyTorch ZIP archives."""
    import zipfile

    findings: list[Finding] = []

    try:
        with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
            for name in zf.namelist():
                lower_name = name.lower()
                # CVE-2025-10155: File extension mismatch - .bin with pickle content
                if (
                    lower_name.endswith(".bin")
                    or lower_name.endswith(".pth")
                    or lower_name.endswith(".pt")
                ):
                    # Check if it's actually a pickle file
                    try:
                        entry_data = zf.read(name)
                        if entry_data[:1] == PICKLE_MAGIC or _looks_like_pickle(entry_data):
                            findings.append(
                                _make_finding(
                                    "HFS-052",
                                    file_path,
                                    f"CVE-2025-10155: File extension mismatch - {name} has pickle content but non-pickle extension",
                                )
                            )
                    except Exception:
                        logger.debug(
                            "Skipping malformed nested pickle metadata during best-effort scan"
                        )

                # CVE-2025-10156: ZIP CRC bypass - bad CRC but PyTorch ignores it
                info = zf.getinfo(name)
                if info.CRC == 0 and info.file_size > 0:
                    # Check if there's a CRC mismatch by trying to read
                    try:
                        entry_data = zf.read(name)
                        findings.append(
                            _make_finding(
                                "HFS-052",
                                file_path,
                                f"CVE-2025-10156: ZIP entry {name} has CRC=0 but readable data ({len(entry_data)} bytes) - CRC bypass",
                            )
                        )
                    except zipfile.BadZipFile:
                        findings.append(
                            _make_finding(
                                "HFS-052",
                                file_path,
                                f"CVE-2025-10156: ZIP entry {name} has CRC mismatch - PickleScan bypass",
                            )
                        )
                    except Exception:
                        logger.debug(
                            "Skipping malformed nested pickle metadata during best-effort scan"
                        )

                # PyTorch stores pickled data in data.pkl or similar
                if lower_name.endswith((".pkl", ".pickle")) or "data.pkl" in lower_name:
                    try:
                        pkl_data = zf.read(name)
                        inner_path = f"{file_path}!{name}"
                        scanner = PickleScanner(inner_path, pkl_data)
                        inner_findings = scanner.scan()
                        # Re-attribute findings to the outer file
                        for f in inner_findings:
                            f.file_path = file_path
                            f.evidence = f"[ZIP:{name}] {f.evidence}"
                        findings.extend(inner_findings)
                    except Exception:
                        logger.debug(
                            "Skipping malformed nested pickle metadata during best-effort scan"
                        )
    except Exception:
        # Not a valid ZIP - might be raw pickle with PK in content
        scanner = PickleScanner(file_path, data)
        findings.extend(scanner.scan())

    return findings


def analyze_pickle_file(file_path: str, data: bytes) -> list[Finding]:
    """Public API: scan a binary file for pickle deserialization attacks."""
    if not (
        is_pickle_file(file_path)
        or data[:1] == PICKLE_MAGIC
        or _looks_like_pickle(data)
        or data[:2] == b"PK"
    ):
        return []
    return scan_pickle_bytes(file_path, data)
